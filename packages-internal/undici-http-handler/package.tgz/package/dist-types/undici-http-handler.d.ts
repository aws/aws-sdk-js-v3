import { HttpResponse, type HttpHandler, type HttpRequest } from "@smithy/core/protocols";
import type { HttpHandlerOptions, Logger } from "@smithy/types";
import { Agent, Dispatcher } from "undici";
/**
 * Options for the UndiciHttpHandler.
 *
 * @public
 */
export interface UndiciHttpHandlerOptions {
    /**
     * You can pass an existing undici Dispatcher (Agent, Pool, Client, etc.)
     * or Agent.Options to have one created for you.
     *
     * Passing your own Dispatcher lets you control the undici version at
     * runtime, independent of this package's bundled version. This lets
     * you pick up upstream performance improvements sooner.
     */
    dispatcher?: Dispatcher | Agent.Options;
    /**
     * Optional logger.
     */
    logger?: Logger;
}
/**
 * This is derived from the smithyContext object. It signals to the
 * UndiciHttpHandler that the request carries an event stream.
 *
 * Event streams are routed through the shared dispatcher just like normal
 * requests. With HTTP/2 (`allowH2`, the default for the internally-managed
 * Agent) streams are multiplexed over a single connection, so a long-lived
 * event stream does not occupy a dedicated socket. With HTTP/1.1, undici's
 * Agent opens additional connections as needed (connections default to
 * unlimited), so concurrent requests are not blocked. Callers who cap
 * `connections` are making an explicit pool-sizing decision that is honored
 * for event streams as well.
 *
 * @internal
 */
type EventStreamSignal = {
    isEventStream?: boolean;
};
/**
 * An HTTP handler that uses undici instead of Node.js native http/https modules.
 * Smithy-compatible request handler backed by undici.
 *
 * @public
 */
export declare class UndiciHttpHandler implements HttpHandler<UndiciHttpHandlerOptions> {
    private config;
    /**
     * Options used to construct the internally-managed Agent, retained so the
     * Agent can be created lazily on the first request. This preserves
     * caller-configured TLS, connect, and timeout settings.
     */
    private internalAgentOptions?;
    constructor(options?: UndiciHttpHandlerOptions);
    destroy(): void;
    handle(request: HttpRequest, { abortSignal, requestTimeout }?: HttpHandlerOptions & EventStreamSignal): Promise<{
        response: HttpResponse;
    }>;
    updateHttpClientConfig<K extends keyof UndiciHttpHandlerOptions>(key: K, value: UndiciHttpHandlerOptions[K]): void;
    httpHandlerConfigs(): {
        dispatcher?: Dispatcher;
        logger?: Logger;
    };
    private getOrCreateDispatcher;
}
export {};
