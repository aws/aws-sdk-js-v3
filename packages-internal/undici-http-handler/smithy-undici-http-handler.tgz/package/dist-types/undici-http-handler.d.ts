import { HttpResponse, type HttpHandler, type HttpRequest } from "@smithy/core/protocols";
import type { HttpHandlerOptions, Logger } from "@smithy/types";
import { Agent, Dispatcher } from "undici";
/**
 * Options for the UndiciHttpHandler.
 *
 * @public
 */
export interface UndiciHttpHandlerOptions {
    /**
     * You can pass an existing undici Dispatcher (Agent, Pool, Client, etc.)
     * or Agent.Options to have one created for you.
     *
     * Passing your own Dispatcher lets you control the undici version at
     * runtime, independent of this package's bundled version. This lets
     * you pick up upstream performance improvements sooner.
     */
    dispatcher?: Dispatcher | Agent.Options;
    /**
     * Optional logger.
     */
    logger?: Logger;
}
/**
 * This is derived from the smithyContext object. This signals to the UndiciHttpHandler
 * that the shared connection pool should not be used. The event stream should
 * have its own dedicated connection.
 *
 * This does not apply to WebSocket event streams, since there is no pooling.
 *
 * @internal
 */
type EventStreamSignal = {
    isEventStream?: boolean;
};
/**
 * An HTTP handler that uses undici instead of Node.js native http/https modules.
 * Smithy-compatible request handler backed by undici.
 *
 * @public
 */
export declare class UndiciHttpHandler implements HttpHandler<UndiciHttpHandlerOptions> {
    private config;
    /**
     * Tracks whether the current dispatcher was created internally by this
     * handler (true) or supplied by the caller as a Dispatcher instance (false).
     *
     * When the caller supplied their own Dispatcher, event-stream requests
     * are routed through it as well so that proxy settings, mock interceptors,
     * and similar behaviors are honored. When we own the dispatcher, event
     * streams get an isolated Client so a long-lived stream does not occupy
     * a slot in the shared pool.
     */
    private isInternalDispatcher;
    /**
     * Options used to construct the internally-managed Agent, retained so they
     * can be propagated to isolated Clients created for event streams. This
     * preserves caller-configured TLS, connect, and timeout settings on the
     * dedicated event-stream connection.
     */
    private internalAgentOptions?;
    constructor(options?: UndiciHttpHandlerOptions);
    destroy(): void;
    handle(request: HttpRequest, { abortSignal, requestTimeout, isEventStream }?: HttpHandlerOptions & EventStreamSignal): Promise<{
        response: HttpResponse;
    }>;
    updateHttpClientConfig<K extends keyof UndiciHttpHandlerOptions>(key: K, value: UndiciHttpHandlerOptions[K]): void;
    httpHandlerConfigs(): {
        dispatcher?: Dispatcher;
        logger?: Logger;
    };
    /**
     * Creates a one-off undici Client for an event stream request.
     * This mirrors NodeHttp2Handler's isolated session behavior — the event stream
     * gets its own dedicated connection that isn't shared with the connection pool.
     *
     * Caller-provided Agent.Options (TLS, connect, timeouts, etc.) are propagated
     * to the isolated Client. Agent/Pool-only keys are stripped. `pipelining` is
     * forced to 0 so the dedicated connection is not pipelined.
     */
    private createIsolatedClient;
    private getOrCreateDispatcher;
}
export {};
