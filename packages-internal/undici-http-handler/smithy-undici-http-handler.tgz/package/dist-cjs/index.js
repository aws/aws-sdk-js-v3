const { buildQueryString, HttpResponse } = require("@smithy/core/protocols");
const { Client, Agent, Dispatcher } = require("undici");

function buildAbortError(abortSignal) {
    const reason = abortSignal && typeof abortSignal === "object" && "reason" in abortSignal
        ? abortSignal.reason
        : undefined;
    if (reason) {
        if (reason instanceof Error) {
            const abortError = new Error("Request aborted");
            abortError.name = "AbortError";
            abortError.cause = reason;
            return abortError;
        }
        const abortError = new Error(String(reason));
        abortError.name = "AbortError";
        return abortError;
    }
    const abortError = new Error("Request aborted");
    abortError.name = "AbortError";
    return abortError;
}

const isDispatcher = (value) => {
    if (value instanceof Dispatcher) {
        return true;
    }
    if (typeof value !== "object" || value === null) {
        return false;
    }
    const candidate = value;
    return (typeof candidate.request === "function" &&
        typeof candidate.close === "function" &&
        typeof candidate.destroy === "function");
};
const AGENT_AND_POOL_ONLY_OPTION_KEYS = ["factory", "maxRedirections", "connections", "interceptors"];
const toClientOptions = (options) => {
    const result = { ...options };
    for (const key of AGENT_AND_POOL_ONLY_OPTION_KEYS) {
        delete result[key];
    }
    return result;
};
class UndiciHttpHandler {
    config;
    isInternalDispatcher = true;
    internalAgentOptions;
    constructor(options) {
        if (options?.dispatcher && isDispatcher(options.dispatcher)) {
            this.config = { ...options, dispatcher: options.dispatcher };
            this.isInternalDispatcher = false;
        }
        else if (options?.dispatcher) {
            this.internalAgentOptions = options.dispatcher;
            const { dispatcher: _ignored, ...rest } = options;
            this.config = rest;
        }
        else {
            this.config = { ...options };
        }
    }
    destroy() {
        this.config.dispatcher?.destroy();
        this.config.dispatcher = undefined;
    }
    async handle(request, { abortSignal, requestTimeout, isEventStream } = {}) {
        const useIsolatedClient = isEventStream && this.isInternalDispatcher;
        const isolatedClient = useIsolatedClient ? this.createIsolatedClient(request) : undefined;
        const dispatcher = isolatedClient ?? this.getOrCreateDispatcher();
        if (abortSignal?.aborted) {
            if (isolatedClient) {
                isolatedClient.destroy();
            }
            throw buildAbortError(abortSignal);
        }
        let path = request.path;
        if (request.query) {
            const queryString = buildQueryString(request.query);
            if (queryString) {
                path += `?${queryString}`;
            }
        }
        const port = request.port ? `:${request.port}` : "";
        let origin;
        if (request.username != null || request.password != null) {
            const username = request.username ?? "";
            const password = request.password ?? "";
            origin = `${request.protocol}//${username}:${password}@${request.hostname}${port}`;
        }
        else {
            origin = `${request.protocol}//${request.hostname}${port}`;
        }
        const headers = request.headers;
        if (headers["Expect"] === "100-continue")
            delete headers["Expect"];
        if (headers["expect"] === "100-continue")
            delete headers["expect"];
        const body = request.body;
        if (body && typeof body.pipe === "function" && typeof body.on === "function") {
            if (headers["transfer-encoding"] === "chunked")
                delete headers["transfer-encoding"];
            if (headers["Transfer-Encoding"] === "chunked")
                delete headers["Transfer-Encoding"];
        }
        const timeout = requestTimeout && requestTimeout > 0 ? requestTimeout : undefined;
        const headersTimeout = timeout;
        const bodyTimeout = timeout;
        try {
            const { statusCode, headers: responseHeaders, body: responseBody, } = await dispatcher.request({
                origin,
                path,
                method: request.method,
                headers,
                body: request.body ?? null,
                headersTimeout,
                bodyTimeout,
                signal: abortSignal,
            });
            let transformedHeaders;
            for (const key in responseHeaders) {
                const value = responseHeaders[key];
                if (Array.isArray(value)) {
                    if (!transformedHeaders) {
                        transformedHeaders = {};
                        for (const k in responseHeaders) {
                            if (k === key)
                                break;
                            transformedHeaders[k] = responseHeaders[k];
                        }
                    }
                    transformedHeaders[key] = value.join(", ");
                }
                else if (transformedHeaders) {
                    transformedHeaders[key] = value;
                }
            }
            const httpResponse = new HttpResponse({
                statusCode,
                headers: (transformedHeaders ?? responseHeaders),
                body: responseBody,
            });
            if (isolatedClient) {
                responseBody.once("close", () => {
                    isolatedClient.close();
                });
            }
            return { response: httpResponse };
        }
        catch (err) {
            if (isolatedClient) {
                isolatedClient.destroy();
            }
            if (err?.code === "UND_ERR_ABORTED") {
                const reason = abortSignal && typeof abortSignal === "object" && "reason" in abortSignal
                    ? abortSignal.reason
                    : undefined;
                const assigned = { name: "AbortError" };
                if (reason !== undefined && err.cause === undefined) {
                    assigned.cause = reason;
                }
                throw Object.assign(err, assigned);
            }
            if (err?.code === "UND_ERR_BODY_TIMEOUT" ||
                err?.code === "UND_ERR_CONNECT_TIMEOUT" ||
                err?.code === "UND_ERR_HEADERS_TIMEOUT") {
                throw Object.assign(err, { name: "TimeoutError" });
            }
            if (err?.code === "UND_ERR_SOCKET") {
                throw Object.assign(err, { name: "RequestTimeout" });
            }
            throw err;
        }
    }
    updateHttpClientConfig(key, value) {
        if (key !== "dispatcher") {
            this.config[key] = value;
            return;
        }
        if (value === undefined) {
            return;
        }
        if (isDispatcher(value)) {
            if (value === this.config.dispatcher) {
                return;
            }
            const previousDispatcher = this.config.dispatcher;
            if (previousDispatcher) {
                previousDispatcher.close();
            }
            this.config.dispatcher = value;
            this.isInternalDispatcher = false;
            this.internalAgentOptions = undefined;
            return;
        }
        if (typeof value === "object" && value !== null) {
            const previousDispatcher = this.config.dispatcher;
            if (previousDispatcher) {
                previousDispatcher.close();
            }
            this.internalAgentOptions = value;
            this.config.dispatcher = undefined;
            this.isInternalDispatcher = true;
            return;
        }
        throw new Error("updateHttpClientConfig: value for 'dispatcher' must be an instance of undici Dispatcher or Agent.Options.");
    }
    httpHandlerConfigs() {
        return { ...this.config };
    }
    createIsolatedClient(request) {
        const port = request.port ? `:${request.port}` : "";
        let origin;
        if (request.username != null || request.password != null) {
            const username = request.username ?? "";
            const password = request.password ?? "";
            origin = `${request.protocol}//${username}:${password}@${request.hostname}${port}`;
        }
        else {
            origin = `${request.protocol}//${request.hostname}${port}`;
        }
        const baseOptions = this.internalAgentOptions ? toClientOptions(this.internalAgentOptions) : {};
        return new Client(origin, {
            ...baseOptions,
            pipelining: 0,
        });
    }
    getOrCreateDispatcher() {
        const { config } = this;
        const { dispatcher } = config;
        if (dispatcher) {
            return dispatcher;
        }
        return (config.dispatcher = new Agent(this.internalAgentOptions ?? {}));
    }
}

exports.UndiciHttpHandler = UndiciHttpHandler;
