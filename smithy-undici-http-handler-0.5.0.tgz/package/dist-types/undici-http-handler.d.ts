import { HttpResponse, type HttpHandler, type HttpRequest } from "@smithy/core/protocols";
import type { HttpHandlerOptions, Logger } from "@smithy/types";
import { Agent, Dispatcher } from "undici";
/**
 * Options for the UndiciHttpHandler.
 *
 * @public
 */
export interface UndiciHttpHandlerOptions {
    /**
     * You can pass an existing undici Dispatcher (Agent, Pool, Client, etc.)
     * or Agent.Options to have one created for you.
     */
    dispatcher?: Dispatcher | Agent.Options;
    /**
     * Optional logger.
     */
    logger?: Logger;
}
/**
 * This is derived from the smithyContext object. This signals to the UndiciHttpHandler
 * that the shared connection pool should not be used. The event stream should
 * have its own dedicated connection.
 *
 * This does not apply to WebSocket event streams, since there is no pooling.
 *
 * @internal
 */
type EventStreamSignal = {
    isEventStream?: boolean;
};
/**
 * An HTTP handler that uses undici instead of Node.js native http/https modules.
 * Smithy-compatible request handler backed by undici.
 *
 * @public
 */
export declare class UndiciHttpHandler implements HttpHandler<UndiciHttpHandlerOptions> {
    private config;
    constructor(options?: UndiciHttpHandlerOptions);
    destroy(): void;
    handle(request: HttpRequest, { abortSignal, requestTimeout, isEventStream }?: HttpHandlerOptions & EventStreamSignal): Promise<{
        response: HttpResponse;
    }>;
    updateHttpClientConfig<K extends keyof UndiciHttpHandlerOptions>(key: K, value: UndiciHttpHandlerOptions[K]): void;
    httpHandlerConfigs(): {
        dispatcher?: Dispatcher;
        logger?: Logger;
    };
    /**
     * Creates a one-off undici Client for an event stream request.
     * This mirrors NodeHttp2Handler's isolated session behavior — the event stream
     * gets its own dedicated connection that isn't shared with the connection pool.
     */
    private createIsolatedClient;
    private getOrCreateDispatcher;
}
export {};
