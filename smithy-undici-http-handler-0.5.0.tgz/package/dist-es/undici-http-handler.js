import { HttpResponse, buildQueryString } from "@smithy/core/protocols";
import { Agent, Client, Dispatcher } from "undici";
const isDispatcher = (value) => value instanceof Dispatcher ||
    (typeof value === "object" && value !== null && typeof value.request === "function");
export class UndiciHttpHandler {
    config;
    constructor(options) {
        if (options?.dispatcher && isDispatcher(options.dispatcher)) {
            this.config = { ...options, dispatcher: options.dispatcher };
        }
        else if (options?.dispatcher) {
            this.config = { ...options, dispatcher: new Agent({ allowH2: true, ...options.dispatcher }) };
        }
        else {
            this.config = { ...options };
        }
    }
    destroy() {
        this.config.dispatcher?.destroy();
        this.config.dispatcher = undefined;
    }
    async handle(request, { abortSignal, requestTimeout, isEventStream } = {}) {
        const isolatedClient = isEventStream ? this.createIsolatedClient(request) : undefined;
        const dispatcher = isolatedClient ?? this.getOrCreateDispatcher();
        if (abortSignal?.aborted) {
            isolatedClient?.destroy();
            throw Object.assign(new Error("Request aborted"), {
                name: "AbortError",
            });
        }
        let path = request.path;
        if (request.query) {
            const queryString = buildQueryString(request.query);
            if (queryString) {
                path += `?${queryString}`;
            }
        }
        const port = request.port ? `:${request.port}` : "";
        let origin;
        if (request.username != null || request.password != null) {
            const username = request.username ?? "";
            const password = request.password ?? "";
            origin = `${request.protocol}//${username}:${password}@${request.hostname}${port}`;
        }
        else {
            origin = `${request.protocol}//${request.hostname}${port}`;
        }
        const headers = request.headers;
        if (headers["Expect"] === "100-continue")
            delete headers["Expect"];
        if (headers["expect"] === "100-continue")
            delete headers["expect"];
        const body = request.body;
        if (body && typeof body.pipe === "function" && typeof body.on === "function") {
            if (headers["transfer-encoding"] === "chunked")
                delete headers["transfer-encoding"];
            if (headers["Transfer-Encoding"] === "chunked")
                delete headers["Transfer-Encoding"];
        }
        const timeout = requestTimeout && requestTimeout > 0 ? requestTimeout : undefined;
        const headersTimeout = timeout;
        const bodyTimeout = timeout;
        try {
            const { statusCode, headers: responseHeaders, body: responseBody, } = await dispatcher.request({
                origin,
                path,
                method: request.method,
                headers,
                body: request.body ?? null,
                headersTimeout,
                bodyTimeout,
                signal: abortSignal,
            });
            let transformedHeaders;
            for (const key in responseHeaders) {
                const value = responseHeaders[key];
                if (Array.isArray(value)) {
                    if (!transformedHeaders) {
                        transformedHeaders = {};
                        for (const k in responseHeaders) {
                            if (k === key)
                                break;
                            transformedHeaders[k] = responseHeaders[k];
                        }
                    }
                    transformedHeaders[key] = value.join(", ");
                }
                else if (transformedHeaders) {
                    transformedHeaders[key] = value;
                }
            }
            const httpResponse = new HttpResponse({
                statusCode,
                headers: (transformedHeaders ?? responseHeaders),
                body: responseBody,
            });
            if (isolatedClient) {
                responseBody.once("close", () => {
                    isolatedClient.destroy();
                });
            }
            return { response: httpResponse };
        }
        catch (err) {
            if (isolatedClient) {
                isolatedClient.destroy();
            }
            if (err?.code === "UND_ERR_ABORTED") {
                throw Object.assign(err, { name: "AbortError" });
            }
            if (err?.code === "UND_ERR_BODY_TIMEOUT" ||
                err?.code === "UND_ERR_CONNECT_TIMEOUT" ||
                err?.code === "UND_ERR_HEADERS_TIMEOUT") {
                throw Object.assign(err, { name: "TimeoutError" });
            }
            if (err?.code === "UND_ERR_SOCKET") {
                throw Object.assign(err, { name: "RequestTimeout" });
            }
            throw err;
        }
    }
    updateHttpClientConfig(key, value) {
        if (key !== "dispatcher") {
            this.config[key] = value;
            return;
        }
        let newDispatcher;
        if (value === undefined) {
            return;
        }
        else if (isDispatcher(value)) {
            newDispatcher = value;
        }
        else if (typeof value === "object" && value !== null) {
            newDispatcher = new Agent({ allowH2: true, ...value });
        }
        else {
            throw new Error("updateHttpClientConfig: value for 'dispatcher' must be an instance of undici Dispatcher or Agent.Options.");
        }
        if (newDispatcher === this.config.dispatcher) {
            return;
        }
        const previousDispatcher = this.config.dispatcher;
        if (previousDispatcher) {
            previousDispatcher.close();
        }
        this.config.dispatcher = newDispatcher;
    }
    httpHandlerConfigs() {
        return { ...this.config };
    }
    createIsolatedClient(request) {
        const port = request.port ? `:${request.port}` : "";
        let origin;
        if (request.username != null || request.password != null) {
            const username = request.username ?? "";
            const password = request.password ?? "";
            origin = `${request.protocol}//${username}:${password}@${request.hostname}${port}`;
        }
        else {
            origin = `${request.protocol}//${request.hostname}${port}`;
        }
        return new Client(origin, {
            allowH2: true,
            pipelining: 0,
        });
    }
    getOrCreateDispatcher() {
        const { config } = this;
        const { dispatcher } = config;
        if (dispatcher) {
            return dispatcher;
        }
        return (config.dispatcher = new Agent({ allowH2: true }));
    }
}
